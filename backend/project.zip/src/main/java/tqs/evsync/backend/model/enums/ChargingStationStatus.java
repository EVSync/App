package tqs.evsync.backend.model.enums;

public enum ChargingStationStatus {
    AVAILABLE,
    OCCUPIED,
    OUT_OF_SERVICE,
    MAINTENANCE
}
