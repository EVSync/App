package tqs.evsync.backend.model.enums;

public enum OutletStatus {
    AVAILABLE,
    OCCUPIED,
    OUT_OF_SERVICE,
    MAINTENANCE
}
