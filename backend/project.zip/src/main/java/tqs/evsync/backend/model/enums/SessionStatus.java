package tqs.evsync.backend.model.enums;

public enum SessionStatus {
    ACTIVE,
    COMPLETED,
    CANCELLED
}
