package tqs.evsync.backend.model.enums;

public enum OperatorType {
    OPERATOR,
    ADMIN
}
