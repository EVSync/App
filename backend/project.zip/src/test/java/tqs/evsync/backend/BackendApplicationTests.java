package tqs.evsync.backend;

//@SpringBootTest
class BackendApplicationTests {

	//@Test
	void contextLoads() {
	}

}